package co.casino.audit.infrastructure.adapter.in.rest;

import co.casino.audit.application.dto.response.AuditLogResponse;
import co.casino.audit.application.dto.response.AuditReportResponse;
import co.casino.audit.application.query.GetReportsQueryHandler;
import co.casino.audit.domain.model.AuditLog;
import co.casino.audit.domain.model.AuditReport;
import co.casino.audit.domain.port.in.GenerateReportUseCase;
import co.casino.audit.domain.port.in.QueryAuditLogsUseCase;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/audit")
@RequiredArgsConstructor
public class AuditController {

    private final QueryAuditLogsUseCase queryAuditLogs;
    private final GenerateReportUseCase generateReport;
    private final GetReportsQueryHandler getReportsQuery;

    // GET /audit/logs?userId=xxx
    // GET /audit/logs?gameId=xxx
    // GET /audit/logs?eventType=xxx
    @GetMapping("/logs")
    public ResponseEntity<List<AuditLogResponse>> getLogs(
            @RequestParam(required = false) String userId,
            @RequestParam(required = false) String gameId,
            @RequestParam(required = false) String eventType) {

        List<AuditLog> results;

        if (userId != null) {
            results = queryAuditLogs.findByUserId(userId);
        } else if (gameId != null) {
            results = queryAuditLogs.findByGameId(gameId);
        } else if (eventType != null) {
            results = queryAuditLogs.findByEventType(eventType);
        } else {
            return ResponseEntity.badRequest().build();
        }

        return ResponseEntity.ok(results.stream().map(this::toLogResponse).collect(Collectors.toList()));
    }

    // POST /audit/reports/generate?userId=xxx
    @PostMapping("/reports/generate")
    public ResponseEntity<AuditReportResponse> generateReport(@RequestParam String userId) {
        AuditReport report = generateReport.execute(userId);
        return ResponseEntity.ok(toReportResponse(report));
    }

    // GET /audit/reports?userId=xxx
    @GetMapping("/reports")
    public ResponseEntity<?> getReport(@RequestParam(required = false) String userId) {
        if (userId != null) {
            return getReportsQuery.findByUserId(userId)
                    .map(r -> ResponseEntity.ok(toReportResponse(r)))
                    .orElse(ResponseEntity.notFound().build());
        }
        List<AuditReportResponse> all = getReportsQuery.findAll().stream()
                .map(this::toReportResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(all);
    }

    // --- mappers ---

    private AuditLogResponse toLogResponse(AuditLog log) {
        return AuditLogResponse.builder()
                .id(log.getId())
                .gameId(log.getGameId())
                .userId(log.getUserId())
                .eventType(log.getEventType())
                .estado(log.getEstado())
                .apuesta(log.getApuesta())
                .pago(log.getPago())
                .timestamp(log.getTimestamp())
                .receivedAt(log.getReceivedAt())
                .build();
    }

    private AuditReportResponse toReportResponse(AuditReport report) {
        return AuditReportResponse.builder()
                .id(report.getId())
                .userId(report.getUserId())
                .totalPartidas(report.getTotalPartidas())
                .totalGanadas(report.getTotalGanadas())
                .totalPerdidas(report.getTotalPerdidas())
                .totalAbandonadas(report.getTotalAbandonadas())
                .totalApostado(report.getTotalApostado())
                .totalPagado(report.getTotalPagado())
                .generatedAt(report.getGeneratedAt())
                .build();
    }
}